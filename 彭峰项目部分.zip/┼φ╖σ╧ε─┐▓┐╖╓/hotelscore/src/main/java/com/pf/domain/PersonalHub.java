package com.pf.domain;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Date;

/**
 * 封装PersonalHub bean
 */
@Component
public class PersonalHub implements Serializable {
    private Integer personalhubid;
    private String personalintroduction;
    private String phone;
    private Integer qq;
    private String WeChat;
    private Date birthday;
    private Integer flag;


    public PersonalHub(Integer personalhubid, String personalintroduction, String phone, Integer qq, Date birthday) {
        this.personalhubid = personalhubid;
        this.personalintroduction = personalintroduction;
        this.phone = phone;
        this.qq = qq;
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return "PersonalHub{" +
                "personalhubid=" + personalhubid +
                ", personalintroduction='" + personalintroduction + '\'' +
                ", phone='" + phone + '\'' +
                ", qq=" + qq +
                ", WeChat='" + WeChat + '\'' +
                ", birthday=" + birthday +
                ", flag=" + flag +
                '}';
    }

    public Integer getPersonalhubid() {
        return personalhubid;
    }

    public void setPersonalhubid(Integer personalhubid) {
        this.personalhubid = personalhubid;
    }

    public String getPersonalintroduction() {
        return personalintroduction;
    }

    public void setPersonalintroduction(String personalintroduction) {
        this.personalintroduction = personalintroduction;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getQq() {
        return qq;
    }

    public void setQq(Integer qq) {
        this.qq = qq;
    }

    public String getWeChat() {
        return WeChat;
    }

    public void setWeChat(String weChat) {
        WeChat = weChat;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }



    public PersonalHub(String personalintroduction, String phone, Integer qq, String weChat, Date birthday) {
        this.personalintroduction = personalintroduction;
        this.phone = phone;
        this.qq = qq;
        WeChat = weChat;
        this.birthday = birthday;
    }

    public PersonalHub(String personalintroduction, String phone, Integer qq, String weChat, Date birthday, Integer flag) {
        this.personalintroduction = personalintroduction;
        this.phone = phone;
        this.qq = qq;
        WeChat = weChat;
        this.birthday = birthday;
        this.flag = flag;
    }

    public PersonalHub(Integer personalhubid, String personalintroduction, String phone, Integer qq, String weChat, Date birthday) {
        this.personalhubid = personalhubid;
        this.personalintroduction = personalintroduction;
        this.phone = phone;
        this.qq = qq;
        WeChat = weChat;
        this.birthday = birthday;
    }

    public PersonalHub(Integer personalhubid, String personalintroduction, String phone, Integer qq, String weChat, Date birthday, Integer flag) {
        this.personalhubid = personalhubid;
        this.personalintroduction = personalintroduction;
        this.phone = phone;
        this.qq = qq;
        WeChat = weChat;
        this.birthday = birthday;
        this.flag = flag;
    }

    public PersonalHub() {
    }
}
