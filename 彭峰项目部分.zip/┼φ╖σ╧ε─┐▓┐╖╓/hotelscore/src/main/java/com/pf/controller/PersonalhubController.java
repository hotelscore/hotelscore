package com.pf.controller;

import com.pf.domain.PersonalHub;
import com.pf.domain.Pic;
import com.pf.service.PersonalHubService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/personalhub")
public class PersonalhubController {

    @Autowired
    private PersonalHubService personalHubService;

    @PostMapping("/showPersonalHubById")
    /**
     * 根据当前用户id,在打开页面时候显示用户中心资料
     */
    public PersonalHub showPersonalHubById(String personalhubid, Model model){
        final PersonalHub personalHub = personalHubService.showPersonalHubById(Integer.parseInt(personalhubid));
        model.addAttribute("id",personalhubid);
        System.out.println("personalHub---->"+personalHub);
        model.addAttribute("personalHub",personalHub);
        System.out.println("model***********************************************"+model);
        return personalHub;
    }

    /**
     * 根据id逻辑删除用户资料
     * @param personalhubid
     * @param model
     * @return
     */
    @PutMapping(value = "/del")
    public Pic del(String personalhubid, Model model){
        System.out.println(personalhubid);
        final Pic pic = new Pic();
        pic.setImgname(personalhubid);
        model.addAttribute("id",personalhubid);
        personalHubService.del(Integer.parseInt(personalhubid));
        final PersonalHub personalHub = new PersonalHub();
        System.out.println("personalHub---->"+personalHub);
        model.addAttribute("personalHub",personalHub);
        return pic;
    }

    /**
     * 在用户想更新页面信息时根据他的用户id将他的用户中心资料展示在模块框上
     * @param personalhubid
     * @param model
     * @return
     */
    @PostMapping("/byid")
    public PersonalHub byid(String personalhubid,Pic pic, Model model){
        model.addAttribute("id",personalhubid);
        final PersonalHub personalHub = personalHubService.showPersonalHubById(Integer.parseInt(personalhubid));

        System.out.println("personalHub---->"+personalHub);
        model.addAttribute("personalHub",personalHub);
        System.out.println(model+"-----------------------------------------------");
        return personalHub;
    }

    /**
     * 更新用户资料
     * @param personalhub
     * @return
     */
    @RequestMapping(value = "/update")
    public void update( PersonalHub personalhub, HttpServletResponse response, HttpServletRequest request) throws IOException, ServletException {

        System.out.println("----------------");
        ModelAndView mv = new ModelAndView();
        mv.addObject("id",personalhub.getPersonalhubid());
        personalHubService.update(personalhub);
        PersonalHub personalHub = personalHubService.showPersonalHubById(personalhub.getPersonalhubid());
        mv.addObject("personalHub",personalHub);
        //response.sendRedirect("personalhub.html");
        request.getSession().setAttribute("personalhub",personalHub);
        request.getRequestDispatcher(request.getContextPath()+"personalhub.html").forward(request,response);

    }

    /**
     * 更换背景图片
     * @param upload1
     * @param request
     * @param model
     * @param response
     * @return
     * @throws IOException
     */

    @RequestMapping("/uploadimg")
    public Map uploadimg( MultipartFile upload1, HttpServletRequest request, Model model, HttpServletResponse response) throws IOException {
        System.out.println("upload1--->"+upload1);
        final Map<Object, String> map = new HashMap<>();
        final String realPath = request.getSession().getServletContext().getRealPath("/hubimg");
        System.out.println("realPath------------>"+realPath);

        final File file = new File(realPath);
        if(!file.exists()){
            file.mkdirs();
        }
        //拿到原始文件名
        final String originalFilename = upload1.getOriginalFilename();
        final String uui = UUID.randomUUID().toString();
        final String uuid = uui.replace("-", "1");
        String realName = uuid+"_"+originalFilename;
        String path = "../hubimg"+"/"+ realName;
        //model.addAttribute("src", JSON.toJSONString(path));
        map.put("path",path);
        System.out.println("src----->"+path);

        upload1.transferTo(new File(realPath,realName));

        System.out.println("realpath"+realPath);

        //response.sendRedirect("/personalhub/a.html");
        System.out.println("pic------->");
        //return pic1;


        return map;
    }

}
