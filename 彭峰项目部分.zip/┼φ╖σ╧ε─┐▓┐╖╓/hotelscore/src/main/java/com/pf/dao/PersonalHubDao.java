package com.pf.dao;

import com.pf.domain.PersonalHub;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

@Repository
public interface PersonalHubDao {
    /**
     * 根据id查询用户个人中心信息并返回
     * @param personalhubid
     * @return
     */

    PersonalHub showPersonalHubById(Integer personalhubid);

    /**
     * 根据id删除个人名片资料
     * @param personalhubid
     */
    void del(Integer personalhubid);

    /**
     * 更新资料
     * @param personalHub
     */
    void update(PersonalHub personalHub);

}
