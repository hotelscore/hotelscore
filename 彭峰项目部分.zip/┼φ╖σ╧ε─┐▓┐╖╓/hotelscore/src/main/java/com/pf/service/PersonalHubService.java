package com.pf.service;

import com.pf.domain.PersonalHub;

public interface PersonalHubService {
    PersonalHub showPersonalHubById(Integer personalhubid);

    /**
     * 根据id删除个人名片资料
     * @param personalhubid
     */
    void del(Integer personalhubid);

    /**
     * 更新资料
     * @param personalHub
     */
    void update(PersonalHub personalHub);
}
