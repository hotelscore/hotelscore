package com.pf.service.Impl;

import com.pf.dao.PersonalHubDao;
import com.pf.domain.PersonalHub;
import com.pf.service.PersonalHubService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("personalHubService")
public class PersonalServiceImpl implements PersonalHubService {

    @Autowired
    private PersonalHubDao personalHubDao;
    @Override
    public PersonalHub showPersonalHubById(Integer personalhubid) {

        final PersonalHub personalHub = personalHubDao.showPersonalHubById(personalhubid);


        return personalHub;
    }

    @Override
    public void del(Integer personalhubid) {
        personalHubDao.del(personalhubid);
    }

    @Override
    public void update(PersonalHub personalHub) {
        personalHubDao.update(personalHub);
    }
}
