package com.pf.domain;

public class Pic {
    private String imgname;

    public Pic() {
    }

    public Pic(String imgname) {
        this.imgname = imgname;
    }

    public String getImgname() {
        return imgname;
    }

    public void setImgname(String imgname) {
        this.imgname = imgname;
    }
}
