/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50709
Source Host           : localhost:3306
Source Database       : hotelscore

Target Server Type    : MYSQL
Target Server Version : 50709
File Encoding         : 65001

Date: 2019-11-08 09:11:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------

-- ----------------------------
-- Table structure for evaluate
-- ----------------------------
DROP TABLE IF EXISTS `evaluate`;
CREATE TABLE `evaluate` (
  `evaluateid` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `level` int(1) NOT NULL,
  `time` date NOT NULL,
  `hotelid` int(16) NOT NULL,
  `userid` int(16) NOT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`evaluateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of evaluate
-- ----------------------------

-- ----------------------------
-- Table structure for hotel
-- ----------------------------
DROP TABLE IF EXISTS `hotel`;
CREATE TABLE `hotel` (
  `hotelid` int(16) NOT NULL AUTO_INCREMENT,
  `hotelname` varchar(32) NOT NULL,
  `introduction` varchar(32) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `pic` varchar(32) NOT NULL,
  `score` int(1) NOT NULL,
  `price` double(16,0) NOT NULL,
  `kind` varchar(255) DEFAULT NULL,
  `service` varchar(255) DEFAULT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`hotelid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hotel
-- ----------------------------

-- ----------------------------
-- Table structure for hotelpicture
-- ----------------------------
DROP TABLE IF EXISTS `hotelpicture`;
CREATE TABLE `hotelpicture` (
  `hotelpictureid` int(16) NOT NULL AUTO_INCREMENT,
  `hotelid` int(16) NOT NULL,
  `pic` varchar(32) NOT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`hotelpictureid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hotelpicture
-- ----------------------------

-- ----------------------------
-- Table structure for personalhub
-- ----------------------------
DROP TABLE IF EXISTS `personalhub`;
CREATE TABLE `personalhub` (
  `personalhubid` int(16) NOT NULL AUTO_INCREMENT,
  `personalintroduction` varchar(255) DEFAULT NULL,
  `phone` varchar(16) DEFAULT NULL,
  `qq` int(16) DEFAULT NULL,
  `WeChat` varchar(32) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`personalhubid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of personalhub
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userid` int(16) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `sex` varchar(1) NOT NULL DEFAULT '男',
  `birthday` date NOT NULL,
  `email` varchar(32) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `pic` varchar(32) NOT NULL,
  `regtime` datetime DEFAULT NULL,
  `flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
